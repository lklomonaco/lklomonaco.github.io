# Set working directory
setwd("C:/Users/Spiri/Documents/LKLUTD.github.io/project")

# load packages
library(ggplot2)
library(lubridate)
library(dplyr)
library(randomForest)
library(glmnet)

# Import CSVs for the Google trends data as a dataframe to build corpus
apples <- read.csv("apples_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
apples <- apples[-c(1, 2), ]
colnames(apples) <- c("date", "trend_score")
apples$date <- as.character(apples$date)  # Convert to character first
apples$date <- ym(apples$date)  # Convert "YYYY-MM" format to Date
apples$trend_score <- as.numeric(apples$trend_score)

beef <- read.csv("beef_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
beef <- beef[-c(1, 2), ]
colnames(beef) <- c("date", "trend_score")
beef$date <- as.character(beef$date)  # Convert to character first
beef$date <- ym(beef$date)  # Convert "YYYY-MM" format to Date
beef$trend_score <- as.numeric(beef$trend_score)

bread <- read.csv("bread_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
bread <- bread[-c(1, 2), ]
colnames(bread) <- c("date", "trend_score")
bread$date <- as.character(bread$date)  # Convert to character first
bread$date <- ym(bread$date)  # Convert "YYYY-MM" format to Date
bread$trend_score <- as.numeric(bread$trend_score)

chicken <- read.csv("chicken_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
chicken <- chicken[-c(1, 2), ]
colnames(chicken) <- c("date", "trend_score")
chicken$date <- as.character(chicken$date)  # Convert to character first
chicken$date <- ym(chicken$date)  # Convert "YYYY-MM" format to Date
chicken$trend_score <- as.numeric(chicken$trend_score)

coffee <- read.csv("coffee_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
coffee <- coffee[-c(1, 2), ]
colnames(coffee) <- c("date", "trend_score")
coffee$date <- as.character(coffee$date)  # Convert to character first
coffee$date <- ym(coffee$date)  # Convert "YYYY-MM" format to Date
coffee$trend_score <- as.numeric(coffee$trend_score)

diesel <- read.csv("diesel_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
diesel <- diesel[-c(1, 2), ]
colnames(diesel) <- c("date", "trend_score")
diesel$date <- as.character(diesel$date)  # Convert to character first
diesel$date <- ym(diesel$date)  # Convert "YYYY-MM" format to Date
diesel$trend_score <- as.numeric(diesel$trend_score)

eggs <- read.csv("eggs_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
eggs <- eggs[-c(1, 2), ]
colnames(eggs) <- c("date", "trend_score")
eggs$date <- as.character(eggs$date)  # Convert to character first
eggs$date <- ym(eggs$date)  # Convert "YYYY-MM" format to Date
eggs$trend_score <- as.numeric(eggs$trend_score)

electricity <- read.csv("electricity_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
electricity <- electricity[-c(1, 2), ]
colnames(electricity) <- c("date", "trend_score")
electricity$date <- as.character(electricity$date)  # Convert to character first
electricity$date <- ym(electricity$date)  # Convert "YYYY-MM" format to Date
electricity$trend_score <- as.numeric(electricity$trend_score)

gasoline <- read.csv("gasoline_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
gasoline <- gasoline[-c(1, 2), ]
colnames(gasoline) <- c("date", "trend_score")
gasoline$date <- as.character(gasoline$date)  # Convert to character first
gasoline$date <- ym(gasoline$date)  # Convert "YYYY-MM" format to Date
gasoline$trend_score <- as.numeric(gasoline$trend_score)

heating_oil <- read.csv("heating_oil_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
heating_oil <- heating_oil[-c(1, 2), ]
colnames(heating_oil) <- c("date", "trend_score")
heating_oil$date <- as.character(heating_oil$date)  # Convert to character first
heating_oil$date <- ym(heating_oil$date)  # Convert "YYYY-MM" format to Date
heating_oil$trend_score <- as.numeric(heating_oil$trend_score)

milk <- read.csv("milk_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
milk <- milk[-c(1, 2), ]
colnames(milk) <- c("date", "trend_score")
milk$date <- as.character(milk$date)  # Convert to character first
milk$date <- ym(milk$date)  # Convert "YYYY-MM" format to Date
milk$trend_score <- as.numeric(milk$trend_score)

natural_gas <- read.csv("natural_gas_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
natural_gas <- natural_gas[-c(1, 2), ]
colnames(natural_gas) <- c("date", "trend_score")
natural_gas$date <- as.character(natural_gas$date)  # Convert to character first
natural_gas$date <- ym(natural_gas$date)  # Convert "YYYY-MM" format to Date
natural_gas$trend_score <- as.numeric(natural_gas$trend_score)

rice <- read.csv("rice_2004present.csv", header = FALSE, stringsAsFactors = FALSE)
rice <- rice[-c(1, 2), ]
colnames(rice) <- c("date", "trend_score")
rice$date <- as.character(rice$date)  # Convert to character first
rice$date <- ym(rice$date)  # Convert "YYYY-MM" format to Date
rice$trend_score <- as.numeric(rice$trend_score)

# make a dataframe of all Google trends search data
google_trends_df <- bind_rows(
  apples %>% mutate(category = "Apples"),
  beef %>% mutate(category = "Beef"),
  bread %>% mutate(category = "Bread"),
  chicken %>% mutate(category = "Chicken"),
  coffee %>% mutate(category = "Coffee"),
  diesel %>% mutate(category = "Diesel"),
  eggs %>% mutate(category = "Eggs"),
  electricity %>% mutate(category = "Electricity"),
  gasoline %>% mutate(category = "Gasoline"),
  heating_oil %>% mutate(category = "Heating Oil"),
  milk %>% mutate(category = "Milk"),
  natural_gas %>% mutate(category = "Natural Gas"),
  rice %>% mutate(category = "Rice")
)

# Create a plot of all goods from Google trends to insure proper import/format
# also gives some insight into general trends of searches
ggplot(google_trends_df, aes(x = date, y = trend_score, color = category)) +
  geom_line(size = 1) +
  labs(title = "Google Search Trends Over Time",
       x = "Date",
       y = "Search Interest") +
  scale_x_date(date_labels = "%Y-%m") +
  theme_minimal()

#import FRED data

fred_data<- read.csv("fredgraph.csv", header = TRUE, stringsAsFactors = FALSE)
colnames(fred_data) <- c("date",
                         "cpi",
                         "consumer_sentiment",
                         "unemployment_rate",
                         "real_income",
                         "producer_price",
                         "fed_rate",
                         "retail_sales",
                         "avg_hourly_earnings",
                         "home_price",
                         "consumer_credit"
                         )
fred_data$date <- as.Date(fred_data$date)  # Convert to date

#merge data

# rename columns for Google trends data to aid merge
colnames(apples) <- c("date", "apples")
colnames(beef) <- c("date", "beef")
colnames(bread) <- c("date", "bread")
colnames(chicken) <- c("date", "chicken")
colnames(coffee) <- c("date", "coffee")
colnames(diesel) <- c("date", "diesel")
colnames(eggs) <- c("date", "eggs")
colnames(electricity) <- c("date", "electricity")
colnames(gasoline) <- c("date", "gasoline")
colnames(heating_oil) <- c("date", "heating_oil")
colnames(milk) <- c("date", "milk")
colnames(natural_gas) <- c("date", "natural_gas")
colnames(rice) <- c("date", "rice")

total_data_df <- apples %>%
  full_join(beef, by = "date") %>%
  full_join(bread, by = "date") %>%
  full_join(chicken, by = "date") %>%
  full_join(coffee, by = "date") %>%
  full_join(diesel, by = "date") %>%
  full_join(eggs, by = "date") %>%
  full_join(electricity, by = "date") %>%
  full_join(gasoline, by = "date") %>%
  full_join(heating_oil, by = "date") %>%
  full_join(milk, by = "date") %>%
  full_join(natural_gas, by = "date") %>%
  full_join(rice, by = "date") %>%
  full_join(fred_data, by = "date")

final_data_df <- total_data_df[-c(255 ,256 , 257), ] # clean data of some N/As

# Convert date to Date format explicitly and create numeric_date
final_data_df$date <- as.Date(final_data_df$date)
final_data_df$numeric_date <- as.numeric(final_data_df$date)

# note that CES0500000003 or Average Hourly Earnings of All Employees starts in
# 2006, so it was removed from the df to not interfere with later regressions

final_data_df$avg_hourly_earnings <- NULL

# Define Google Trends variables and economic indicators
google_trends_vars <- c("apples", "beef", "bread", "chicken", "coffee", "diesel", 
                        "eggs", "electricity", "gasoline", "heating_oil", "milk", 
                        "natural_gas", "rice")
economic_vars <- c("unemployment_rate", "real_income", "producer_price", 
                   "fed_rate", "retail_sales", "home_price", "consumer_credit")

# Create a separate dataframe with lagged Google Trends variables (1-month lag)
data_with_lags <- final_data_df %>%
  mutate(across(all_of(google_trends_vars), ~lag(., n = 1), .names = "{.col}_lag")) %>%
  na.omit()  # Remove rows with NA due to lagging

# Define train-test split (80% quantile based on time)
split_date_num <- quantile(as.numeric(data_with_lags$date), 0.8, na.rm = TRUE)
split_date <- as.Date(split_date_num, origin = "1970-01-01")
train_data <- data_with_lags %>% filter(date <= split_date)
test_data <- data_with_lags %>% filter(date > split_date)

# Verify split
cat("Training set rows:", nrow(train_data), "\n")
cat("Testing set rows:", nrow(test_data), "\n")

# Function to plot predicted vs. actual (consistent across all models)
plot_pred_vs_actual <- function(actual, predicted, title) {
  ggplot(data.frame(actual = actual, predicted = predicted), 
         aes(x = actual, y = predicted)) +
    geom_point(color = "blue", alpha = 0.6) +
    geom_abline(intercept = 0, slope = 1, color = "red", linetype = "dashed") +
    labs(title = title, x = "Actual", y = "Predicted") +
    theme_minimal()
}

# --- Models for CPI ---

### 1. Linear Regression for CPI
# Equation: cpi ~ apples + beef + ... + rice + consumer_sentiment + economic_vars
cpi_lin_predictors <- c(google_trends_vars, "consumer_sentiment", economic_vars)
cpi_lin_formula <- as.formula(paste("cpi ~", paste(cpi_lin_predictors, collapse = " + ")))
print(cpi_lin_formula)
cpi_lin_model_0 <- lm(cpi_lin_formula, data = final_data_df)
summary(cpi_lin_model_0)
cpi_lin_model <- lm(cpi_lin_formula, data = train_data)
cpi_lin_pred <- predict(cpi_lin_model, newdata = test_data)
cpi_lin_rmse <- sqrt(mean((test_data$cpi - cpi_lin_pred)^2, na.rm = TRUE))
cat("Linear Regression (CPI) - Test RMSE:", round(cpi_lin_rmse, 2), "\n")
# summary(cpi_lin_model)
plot_pred_vs_actual(test_data$cpi, cpi_lin_pred, "Linear Regression: Actual vs. Predicted CPI")

### 2. Lagged Linear Regression for CPI
# Equation: cpi ~ apples_lag + beef_lag + ... + rice_lag + consumer_sentiment + economic_vars
cpi_lagged_predictors <- c(paste0(google_trends_vars, "_lag"), "consumer_sentiment", economic_vars)
cpi_lagged_formula <- as.formula(paste("cpi ~", paste(cpi_lagged_predictors, collapse = " + ")))
print(cpi_lagged_formula)
cpi_lagged_model_0 <- lm(cpi_lagged_formula, data = data_with_lags)
summary(cpi_lagged_model_0)
cpi_lagged_model <- lm(cpi_lagged_formula, data = train_data)
cpi_lagged_pred <- predict(cpi_lagged_model, newdata = test_data)
cpi_lagged_rmse <- sqrt(mean((test_data$cpi - cpi_lagged_pred)^2, na.rm = TRUE))
cat("Lagged Linear Regression (CPI) - Test RMSE:", round(cpi_lagged_rmse, 2), "\n")
# summary(cpi_lagged_model)
plot_pred_vs_actual(test_data$cpi, cpi_lagged_pred, "Lagged Linear Regression: Actual vs. Predicted CPI")

### 3. LASSO Regression for CPI
# Predictors: same as linear regression (apples + beef + ... + rice + consumer_sentiment + economic_vars)
X_train_cpi <- as.matrix(train_data[, cpi_lin_predictors])
y_train_cpi <- train_data$cpi
X_test_cpi <- as.matrix(test_data[, cpi_lin_predictors])
set.seed(123)
cpi_lasso_cv <- cv.glmnet(X_train_cpi, y_train_cpi, alpha = 1, standardize = TRUE)
cpi_best_lambda <- cpi_lasso_cv$lambda.min
cpi_lasso_model <- glmnet(X_train_cpi, y_train_cpi, alpha = 1, lambda = cpi_best_lambda, standardize = TRUE)
cpi_lasso_pred <- predict(cpi_lasso_model, newx = X_test_cpi, s = cpi_best_lambda)[, 1]
cpi_lasso_rmse <- sqrt(mean((test_data$cpi - cpi_lasso_pred)^2, na.rm = TRUE))
cat("LASSO Regression (CPI) - Test RMSE:", round(cpi_lasso_rmse, 2), "\n")
coef(cpi_lasso_model)
# Coefficient path plot
plot(cpi_lasso_cv, main = "LASSO Cross-Validation for CPI")
plot_pred_vs_actual(test_data$cpi, cpi_lasso_pred, "LASSO: Actual vs. Predicted CPI")

### 4. Random Forest for CPI
# Predictors: same as linear regression (apples + beef + ... + rice + consumer_sentiment + economic_vars)
set.seed(123)
cpi_rf_model <- randomForest(cpi ~ ., data = train_data[, c("cpi", cpi_lin_predictors)], 
                             importance = TRUE, ntree = 500)
cpi_rf_pred <- predict(cpi_rf_model, newdata = test_data)
cpi_rf_rmse <- sqrt(mean((test_data$cpi - cpi_rf_pred)^2, na.rm = TRUE))
cat("Random Forest (CPI) - Test RMSE:", round(cpi_rf_rmse, 2), "\n")
importance_scores_cpi_rf_model <- importance(cpi_rf_model)
print(importance_scores_cpi_rf_model)
varImpPlot(cpi_rf_model, type = 1, main = "Random Forest Feature Importance for CPI")
plot_pred_vs_actual(test_data$cpi, cpi_rf_pred, "Random Forest: Actual vs. Predicted CPI")

# --- Models for Consumer Sentiment ---

### 1. Linear Regression for Consumer Sentiment
# Equation: consumer_sentiment ~ cpi + apples + beef + ... + rice + economic_vars
cs_lin_predictors <- c("cpi", google_trends_vars, economic_vars)
cs_lin_formula <- as.formula(paste("consumer_sentiment ~", paste(cs_lin_predictors, collapse = " + ")))
cs_lin_model_0 <- lm(cs_lin_formula, data = final_data_df)
summary(cs_lin_model_0)
cs_lin_model <- lm(cs_lin_formula, data = train_data)
cs_lin_pred <- predict(cs_lin_model, newdata = test_data)
cs_lin_rmse <- sqrt(mean((test_data$consumer_sentiment - cs_lin_pred)^2, na.rm = TRUE))
cat("Linear Regression (Consumer Sentiment) - Test RMSE:", round(cs_lin_rmse, 2), "\n")
# summary(cs_lin_model)
plot_pred_vs_actual(test_data$consumer_sentiment, cs_lin_pred, 
                    "Linear Regression: Actual vs. Predicted Consumer Sentiment")

### 2. Lagged Linear Regression for Consumer Sentiment
# Equation: consumer_sentiment ~ cpi + apples_lag + beef_lag + ... + rice_lag + economic_vars
cs_lagged_predictors <- c("cpi", paste0(google_trends_vars, "_lag"), economic_vars)
cs_lagged_formula <- as.formula(paste("consumer_sentiment ~", paste(cs_lagged_predictors, collapse = " + ")))
cs_lagged_model_0 <- lm(cs_lagged_formula, data = data_with_lags)
summary(cs_lagged_model_0)
cs_lagged_model <- lm(cs_lagged_formula, data = train_data)
cs_lagged_pred <- predict(cs_lagged_model, newdata = test_data)
cs_lagged_rmse <- sqrt(mean((test_data$consumer_sentiment - cs_lagged_pred)^2, na.rm = TRUE))
cat("Lagged Linear Regression (Consumer Sentiment) - Test RMSE:", round(cs_lagged_rmse, 2), "\n")
# summary(cs_lagged_model)
plot_pred_vs_actual(test_data$consumer_sentiment, cs_lagged_pred, 
                    "Lagged Linear Regression: Actual vs. Predicted Consumer Sentiment")

### 3. LASSO Regression for Consumer Sentiment
# Predictors: same as linear regression (cpi + apples + beef + ... + rice + economic_vars)
X_train_cs <- as.matrix(train_data[, cs_lin_predictors])
y_train_cs <- train_data$consumer_sentiment
X_test_cs <- as.matrix(test_data[, cs_lin_predictors])
set.seed(123)
cs_lasso_cv <- cv.glmnet(X_train_cs, y_train_cs, alpha = 1, standardize = TRUE)
cs_best_lambda <- cs_lasso_cv$lambda.min
cs_lasso_model <- glmnet(X_train_cs, y_train_cs, alpha = 1, lambda = cs_best_lambda, standardize = TRUE)
cs_lasso_pred <- predict(cs_lasso_model, newx = X_test_cs, s = cs_best_lambda)[, 1]
cs_lasso_rmse <- sqrt(mean((test_data$consumer_sentiment - cs_lasso_pred)^2, na.rm = TRUE))
cat("LASSO Regression (Consumer Sentiment) - Test RMSE:", round(cs_lasso_rmse, 2), "\n")
coef(cs_lasso_model)
# Coefficient path plot
plot(cs_lasso_cv, main = "LASSO Cross-Validation for Consumer Sentiment")
plot_pred_vs_actual(test_data$consumer_sentiment, cs_lasso_pred, 
                    "LASSO: Actual vs. Predicted Consumer Sentiment")

### 4. Random Forest for Consumer Sentiment
# Predictors: same as linear regression (cpi + apples + beef + ... + rice + economic_vars)
set.seed(123)
cs_rf_model <- randomForest(consumer_sentiment ~ ., data = train_data[, c("consumer_sentiment", cs_lin_predictors)], 
                            importance = TRUE, ntree = 500)
cs_rf_pred <- predict(cs_rf_model, newdata = test_data)
cs_rf_rmse <- sqrt(mean((test_data$consumer_sentiment - cs_rf_pred)^2, na.rm = TRUE))
cat("Random Forest (Consumer Sentiment) - Test RMSE:", round(cs_rf_rmse, 2), "\n")
importance_scores_cs_rf_model <- importance(cs_rf_model)
print(importance_scores_cs_rf_model)
varImpPlot(cs_rf_model, type = 1, main = "Random Forest Feature Importance for Consumer Sentiment")
plot_pred_vs_actual(test_data$consumer_sentiment, cs_rf_pred, 
                    "Random Forest: Actual vs. Predicted Consumer Sentiment")
